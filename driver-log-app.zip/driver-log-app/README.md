# Driver Daily Log (standalone)

Phone-number + PIN login. Drivers see only their own entries. Phones listed in ADMIN_PHONES become accountant/owner accounts: they see every driver individually (read-only).

## Run locally (Node 22.13+; no npm install needed)
    ADMIN_PHONES=9XXXXXXXXX SECRET=some-long-random-text node server.js
Open http://localhost:3000. The accountant registers (Register tab) using a phone number listed in ADMIN_PHONES.

## Deploy (Render.com example)
1. Put this folder in a GitHub repo. New > Web Service > pick the repo.
2. Build command: (empty). Start command: `node server.js`. Runtime: Node 22+.
3. Environment variables: SECRET (long random text), ADMIN_PHONES (comma-separated), DB_PATH=/var/data/data.db
4. Add a Persistent Disk mounted at /var/data (otherwise the database is wiped on each deploy).
5. Give drivers the https URL; they can add it to their phone home screen.

Back up data.db regularly.

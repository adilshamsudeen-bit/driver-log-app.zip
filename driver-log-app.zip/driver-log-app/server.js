const http = require("http"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");

const PORT = process.env.PORT || 3000;
const SECRET = process.env.SECRET || "change-this-secret";
const norm = p => String(p || "").replace(/\D/g, "").slice(-10);
const ADMINS = (process.env.ADMIN_PHONES || "").split(",").map(norm).filter(Boolean);
const LIMIT = 150;

const db = new DatabaseSync(process.env.DB_PATH || path.join(__dirname, "data.db"));
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, phone TEXT UNIQUE, name TEXT, role TEXT, salt TEXT, hash TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY, user_id INTEGER, date TEXT, from_t TEXT, to_t TEXT, veh TEXT,
 uber REAL, other REAL, cash REAL, cng REAL, petrol REAL, gpay REAL, cashpaid REAL, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS e_u ON entries(user_id, date);`);

const mac = s => crypto.createHmac("sha256", SECRET).update(s).digest("base64url");
const mint = id => { const p = id + "." + (Date.now() + 30 * 864e5); return p + "." + mac(p); };
const hash = (pin, salt) => crypto.scryptSync(pin, salt, 32).toString("hex");
const send = (res, c, o) => { res.writeHead(c, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
const num = v => Math.max(0, Math.min(1e7, Number(v) || 0));
const tries = {};

function who(req) {
  const t = (req.headers.authorization || "").slice(7).split(".");
  if (t.length !== 3) return null;
  const a = Buffer.from(mac(t[0] + "." + t[1])), b = Buffer.from(t[2]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b) || +t[1] < Date.now()) return null;
  return db.prepare("SELECT id,phone,name,role FROM users WHERE id=?").get(+t[0]) || null;
}
const clean = b => ({
  date: /^\d{4}-\d\d-\d\d$/.test(b.date) ? b.date : null, from: String(b.from || "").slice(0, 10), to: String(b.to || "").slice(0, 10),
  veh: String(b.veh || "").trim().toUpperCase().slice(0, 20), uber: num(b.uber), other: num(b.other), cash: num(b.cash),
  cng: num(b.cng), petrol: num(b.petrol), gpay: num(b.gpay), cashpaid: num(b.cashpaid)
});
const problem = e => !e.date || !e.veh ? "Date and vehicle number are required"
  : e.cash - (e.cng + e.petrol) - e.gpay - e.cashpaid > LIMIT ? "Difference is above the ₹150 daily limit. Clear the balance first." : null;
const out = r => ({ id: r.id, date: r.date, from: r.from_t, to: r.to_t, veh: r.veh, uber: r.uber, other: r.other, cash: r.cash, cng: r.cng, petrol: r.petrol, gpay: r.gpay, cashpaid: r.cashpaid });
const COLS = "date,from_t,to_t,veh,uber,other,cash,cng,petrol,gpay,cashpaid";
const vals = e => [e.date, e.from, e.to, e.veh, e.uber, e.other, e.cash, e.cng, e.petrol, e.gpay, e.cashpaid];

function route(req, res, u, b) {
  const p = u.pathname, m = req.method;
  if (m === "POST" && (p === "/api/register" || p === "/api/login")) {
    const phone = norm(b.phone), pin = String(b.pin || "");
    if (phone.length !== 10 || !/^\d{4,6}$/.test(pin)) return send(res, 400, { error: "Enter a 10-digit phone number and a 4–6 digit PIN" });
    const t = tries[phone] || (tries[phone] = { n: 0, at: Date.now() });
    if (Date.now() - t.at > 9e5) { t.n = 0; t.at = Date.now(); }
    if (t.n >= 5) return send(res, 429, { error: "Too many attempts. Try again in 15 minutes." });
    let user = db.prepare("SELECT * FROM users WHERE phone=?").get(phone);
    if (p.endsWith("register")) {
      if (user) return send(res, 409, { error: "This phone is already registered. Please log in." });
      const name = String(b.name || "").trim().slice(0, 40);
      if (!name) return send(res, 400, { error: "Enter your name" });
      const salt = crypto.randomBytes(8).toString("hex");
      const r = db.prepare("INSERT INTO users(phone,name,role,salt,hash) VALUES(?,?,?,?,?)").run(phone, name, ADMINS.includes(phone) ? "admin" : "driver", salt, hash(pin, salt));
      user = db.prepare("SELECT * FROM users WHERE id=?").get(r.lastInsertRowid);
    } else if (!user || hash(pin, user.salt) !== user.hash) { t.n++; return send(res, 401, { error: "Wrong phone number or PIN" }); }
    t.n = 0;
    return send(res, 200, { token: mint(user.id) });
  }
  const me = who(req);
  if (!me) return send(res, 401, { error: "Please log in" });
  if (p === "/api/me") return send(res, 200, { user: me });
  if (p === "/api/drivers" && me.role === "admin")
    return send(res, 200, { drivers: db.prepare("SELECT id,name,phone FROM users WHERE role='driver' ORDER BY name").all() });
  if (p === "/api/entries" && m === "GET") {
    const uid = me.role === "admin" ? +u.searchParams.get("driver") : me.id;
    return send(res, 200, db.prepare("SELECT * FROM entries WHERE user_id=? ORDER BY date DESC,id DESC").all(uid).map(out));
  }
  if (me.role !== "driver") return send(res, 403, { error: "Read-only access" });
  if (p === "/api/entries" && m === "POST") {
    const e = clean(b), err = problem(e); if (err) return send(res, 400, { error: err });
    const r = db.prepare(`INSERT INTO entries(user_id,${COLS}) VALUES(?,${COLS.split(",").map(() => "?")})`).run(me.id, ...vals(e));
    return send(res, 200, { id: Number(r.lastInsertRowid) });
  }
  const m2 = p.match(/^\/api\/entries\/(\d+)$/);
  if (m2 && m === "DELETE") { db.prepare("DELETE FROM entries WHERE id=? AND user_id=?").run(+m2[1], me.id); return send(res, 200, { ok: 1 }); }
  if (m2 && m === "PUT") {
    const e = clean(b), err = problem(e); if (err) return send(res, 400, { error: err });
    db.prepare(`UPDATE entries SET ${COLS.split(",").map(c => c + "=?")} WHERE id=? AND user_id=?`).run(...vals(e), +m2[1], me.id);
    return send(res, 200, { ok: 1 });
  }
  send(res, 404, { error: "Not found" });
}

http.createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  if (!u.pathname.startsWith("/api/")) {
    if (u.pathname === "/") { res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }); return res.end(fs.readFileSync(path.join(__dirname, "public", "index.html"))); }
    res.writeHead(404); return res.end("Not found");
  }
  let raw = ""; req.on("data", c => { raw += c; if (raw.length > 1e4) req.destroy(); });
  req.on("end", () => { try { route(req, res, u, raw ? JSON.parse(raw) : {}); } catch (e) { console.error(e); send(res, 400, { error: "Bad request" }); } });
}).listen(PORT, () => console.log("Driver Log running on port " + PORT));
